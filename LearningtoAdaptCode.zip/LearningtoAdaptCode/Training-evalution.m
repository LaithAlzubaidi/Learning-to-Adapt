

%% Measure network accuracy
yfit = classify(MobilTLbigFinger, allImages); 
accuracy = mean(yfit == allImages.Labels)
%%

%% confusion metrix %Test29  ,'Hand-Negative','Hand-Positive'
RE= combineddataTestlLabel4xx;                      
cm = confusionmat(RE, yfit)
%[cm,order] = confusionmat(RE, yfit,'Order',{'Shoulder-Negative','Shoulder-Positive','Hand-Negative','Hand-Positive','Forearm-Negative','Forearm-Positive','Humerus-Negative','Humerus-Positive','Wrist-Negative','Wrist-Positive'})
cm1= bsxfun (@rdivide, cm, sum(cm,2))
mean(diag(cm1))
%%
cm2 = confusionchart(RE, yfit);
%% 488,438,560,420


% Calculate confusion matrix
conf_mat = confusionmat(RE, yfit);
% Calculate overall metrics
num_classes = size(conf_mat, 1);
tp = zeros(num_classes, 1);
tn = zeros(num_classes, 1);
fp = zeros(num_classes, 1);
fn = zeros(num_classes, 1);
for i = 1:num_classes
    tp(i) = conf_mat(i,i);
    tn(i) = sum(sum(conf_mat))-tp(i)-sum(conf_mat(i,:))-sum(conf_mat(:,i))+2*conf_mat(i,i);
    fp(i) = sum(conf_mat(:,i))-tp(i);
    fn(i) = sum(conf_mat(i,:))-tp(i);
end
accuracy = sum(tp)/sum(sum(conf_mat));
specificity = sum(tn./(tn+fp))/num_classes;
recall = sum(tp./(tp+fn))/num_classes;
precision = sum(tp./(tp+fp))/num_classes;
f1_score = (2*(precision * recall)) / (precision+recall);
% Display results
fprintf('Confusion matrix:\n');
disp(conf_mat);
fprintf('Accuracy: %.3f\n', accuracy);
fprintf('Specificity: %.3f\n', specificity);
fprintf('Recall: %.3f\n', recall);
fprintf('Precision: %.3f\n', precision);
fprintf('F1-score: %.3f\n', f1_score);



%% old
tp_m = diag(cm);

 for i = 1:2
    TP = tp_m(i);
    FP = sum(cm(:, i), 1) - TP;
    FN = sum(cm(i, :), 2) - TP;
    TN = sum(cm(:)) - TP - FP - FN;

    Accuracy = (TP+TN)./(TP+FP+TN+FN);

    TPR = TP./(TP + FN);%tp/actual positive  RECALL SENSITIVITY
    if isnan(TPR)
        TPR = 0;
    end
    PPV = TP./ (TP + FP); % tp / predicted positive PRECISION
    if isnan(PPV)
        PPV = 0;
    end
    TNR = TN./ (TN+FP); %tn/ actual negative  SPECIFICITY
    if isnan(TNR)
        TNR = 0;
    end
    FPR = FP./ (TN+FP);
    if isnan(FPR)
        FPR = 0;
    end
    FScore = (2*(PPV * TPR)) / (PPV+TPR);

    if isnan(FScore)
        FScore = 0;
    end

    
 end

fprintf('Accuracy = %2.2f.\n',100*Accuracy);
fprintf('SPECIFICITY = %2.2f.\n',100*TNR);
fprintf('RECALL or SENSITIVITY = %2.2f.\n',100*TPR);
fprintf('PRECISION = %2.2f.\n',100*PPV);
fprintf('F1-Score = %2.2f.\n',100*FScore);


%%
idx = [3 4 9 12 13 36 39 371 372 391 413 458];
figure
for i = 1:numel(idx)
    subplot(3,4,i)
    I = readimage(allImages,idx(i));
%     imgsValidation.ReadFcn = @customReadDatastoreImage;
    label = yfit(idx(i));
%     prob = num2str(100*max(predictedLabels(idx(i),:)),2);
    imshow(I)
    title(char(label))
end



[YPred,probs] = classify(mobilenetv2Shoulder,I);
imshow(I)
label = YPred;
title(string(label) + ", " + num2str(100*max(probs),3) + "%");

%%  

idx = [2 551 10 74 484 86 89 110 523 112 206 498]; % wrong

%idx = [37 562 3 4 383 219 30 63 156 320 545 321];

%idx = [102 117 242 471];
figure
for i = 1:numel(idx)
    subplot(3,4,i)
    I = readimage(allImages,idx(i));
%     imgsValidation.ReadFcn = @customReadDatastoreImage;
 [YPred,probs] = classify(inceptionresnetv2TLFra2,I);
%     prob = num2str(100*max(predictedLabels(idx(i),:)),2);
    imshow(I)
    label = YPred;
title(string(label) + ", " + num2str(100*max(probs),3) + "%");
end



%%

function data=customReadDatastoreImage(filename)
% code from default function: 
onState = warning('off', 'backtrace'); 
c = onCleanup(@() warning(onState)); 
data = imread(filename); % added lines: 
data = data(:,:,min(1:3, end)); 
data = imresize(data,[299 299]);
end