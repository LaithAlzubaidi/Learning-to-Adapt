A= 'C:\Users\ALZUBAID\OneDrive - Queensland University of Technology\Desktop\New-Orthopedics\Shoulder-done';
parentDir = A;
 dataDir = 'Train';

%%  Divide into Training and Validation Data

TrainShoulder = imageDatastore(fullfile(parentDir,dataDir),...
    'IncludeSubfolders',true,...
    'LabelSource','foldernames');
 TrainShoulder.ReadFcn = @customReadDatastoreImage;
disp(['Number of Train29: ',num2str(numel(TrainShoulder.Files))]);

%%
B= 'C:\Users\ALZUBAID\OneDrive - Queensland University of Technology\Desktop\New-Orthopedics\Shoulder-done';
parentDir = B;
 dataDir = 'Test';

%%  Divide into Training and Validation Data

TestShoulder= imageDatastore(fullfile(parentDir,dataDir),...
    'IncludeSubfolders',true,...
    'LabelSource','foldernames');
  TestShoulder.ReadFcn = @customReadDatastoreImage;
disp(['Number of Test29: ',num2str(numel(TestShoulder.Files))]);
%%
net1 = xceptionbigTLshoulderV3;
net2 = inceptionresnetvbigTLshoulderV3;



% analyzeNetwork(net1)
%% 
% last FC to extract the features
layer1='newTLlayerShoulder1';
layer2='newTLlayerShoulder1';


%%

FeatureTrainXCEPTION = activations(net1,TrainShoulder,layer1,'outputAs','rows');
 FeatureTestXCEPTION = activations(net1,TestShoulder,layer1,'outputAs','rows');

whos FeatureTrainXCEPTION



FeatureTrainInceptionRes = activations(net2,TrainShoulder,layer2,'outputAs','rows');
 FeatureTest2InceptionRes = activations(net2,TestShoulder,layer2,'outputAs','rows');

whos FeatureTrainInceptionRes




 %%
 FeatureTrainallShoulder=[FeatureTrainXCEPTION FeatureTrainInceptionRes];
 FeatureTestallShoulder=[FeatureTestXCEPTION FeatureTest2InceptionRes];



%%

TrainLabelShoulder=TrainShoulder.Labels;
TestLabelShoulder=TestShoulder.Labels;


%%
function data=customReadDatastoreImage(filename)
% code from default function: 
onState = warning('off', 'backtrace'); 
c = onCleanup(@() warning(onState)); 
data = imread(filename); % added lines: 
data = data(:,:,min(1:3, end)); 
data = imresize(data,[299 299]);
end
