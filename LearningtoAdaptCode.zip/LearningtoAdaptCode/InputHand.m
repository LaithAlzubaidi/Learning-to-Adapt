A= 'C:\Users\ALZUBAID\OneDrive - Queensland University of Technology\Desktop\New-Orthopedics\Hand-Done';
parentDir = A;
 dataDir = 'Train';

%%  Divide into Training and Validation Data

TrainHand = imageDatastore(fullfile(parentDir,dataDir),...
    'IncludeSubfolders',true,...
    'LabelSource','foldernames');
 TrainHand.ReadFcn = @customReadDatastoreImage;
disp(['Number of Train29: ',num2str(numel(TrainHand.Files))]);

%%
B= 'C:\Users\ALZUBAID\OneDrive - Queensland University of Technology\Desktop\New-Orthopedics\Hand-Done';
parentDir = B;
 dataDir = 'Test';

%%  Divide into Training and Validation Data

TestHand= imageDatastore(fullfile(parentDir,dataDir),...
    'IncludeSubfolders',true,...
    'LabelSource','foldernames');
  TestHand.ReadFcn = @customReadDatastoreImage;
disp(['Number of Test29: ',num2str(numel(TestHand.Files))]);
%%
net1 = xceptionTLbigHandV3;
net2 = inceptionresnetv2TLHand;



% analyzeNetwork(net1)
%% 
% last FC to extract the features
layer1='newHand';
layer2='newHand';


%%

FeatureTrainXCEPTION = activations(net1,TrainHand,layer1,'outputAs','rows');
 FeatureTestXCEPTION = activations(net1,TestHand,layer1,'outputAs','rows');

whos FeatureTrainXCEPTION



FeatureTrainInceptionRes = activations(net2,TrainHand,layer2,'outputAs','rows');
 FeatureTest2InceptionRes = activations(net2,TestHand,layer2,'outputAs','rows');

whos FeatureTrainInceptionRes




 %%
 FeatureTrainallHand=[FeatureTrainXCEPTION FeatureTrainInceptionRes];
 FeatureTestallHand=[FeatureTestXCEPTION FeatureTest2InceptionRes];



%%

TrainLabelHand=TrainHand.Labels;
TestLabelHand=TestHand.Labels;


%%
function data=customReadDatastoreImage(filename)
% code from default function: 
onState = warning('off', 'backtrace'); 
c = onCleanup(@() warning(onState)); 
data = imread(filename); % added lines: 
data = data(:,:,min(1:3, end)); 
data = imresize(data,[299 299]);
end
