
combineddataTrainall4xx = vertcat(FeatureTrainallShoulder,FeatureTrainallHand,FeatureTrainallForearm);
combineddataTrainallLabel4xx = vertcat(TrainLabelShoulder,TrainLabelHand,TrainLabelForearm);


combineddataTestall4xx = vertcat(FeatureTestallShoulder,FeatureTestallHand, FeatureTestallForearm);
combineddataTestlLabel4xx = vertcat(TestLabelShoulder,TestLabelHand,TestLabelForearm);





%%
combineddataTrainall = vertcat(FeatureTrainallElbow,FeatureTrainallForearm,FeatureTrainallHand,FeatureTrainallHumerus,FeatureTrainallShoulder,FeatureTrainallFinger);
combineddataTrainallLabel = vertcat(TrainLabelelbow,TrainLabelForearm,TrainLabelHand,TrainLabelHumerus,TrainLabelShoulder, TrainLabelFinger);


combineddataTestall = vertcat(FeatureTestallElbow,FeatureTestallForearm,FeatureTestallHand,FeatureTestallHumerus,FeatureTestallShoulder,FeatureTestallFinger);
combineddataTestlLabel = vertcat(TestLabelelbow,TestLabelForearm,TestLabelHand,TestLabelHumerus,TestLabelShoulder,TestLabelFinger);



%%
% Train SVM classifier fitcsvm or fitcecoc
svmModel = fitcecoc(combineddataTrainall4xx, combineddataTrainallLabel4xx);


% Predict labels for test data
predictedLabels = predict(svmModel, combineddataTestall4xx);

accuracy = mean(predictedLabels == combineddataTestlLabel4xx)

%% random Forest


% Set the number of trees in the Random Forest
numTrees = 1000;

% Train the Random Forest classifier
randomForest = TreeBagger(numTrees, combineddataTrainall4xx, combineddataTrainallLabel4xx, 'Method', 'classification');

% Make predictions using the Random Forest classifier
predictions = predict(randomForest, combineddataTestall4xx);

accuracy = mean(predictions == combineddataTestlLabel4xx)
%%
yfit = svm4.predictFcn(combineddataTestall4xx); 

accuracy = mean(yfit == combineddataTestlLabel4xx)

fitcensemble


                                                                                     