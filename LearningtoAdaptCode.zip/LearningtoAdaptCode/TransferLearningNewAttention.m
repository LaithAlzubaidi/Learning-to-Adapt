%% Load 
A= 'C:\Users\ALZUBAID\OneDrive - Queensland University of Technology\Desktop\New-Orthopedics\Pattren-Recognision\Task3';
parentDir = A;
 dataDir = 'Data';
% dataDir = 'TargetDataS';



%%  Divide into Training and Validation Data

allImages = imageDatastore(fullfile(parentDir,dataDir),...
    'IncludeSubfolders',true,...
    'LabelSource','foldernames');
 allImages.ReadFcn = @customReadDatastoreImage;
disp(['Number of allImages: ',num2str(numel(allImages.Files))]);

 %% show image from imageDatastore

 img = readimage(allImages,16);
imshow(img)
%%
rng default
[imgsTrain,imgsValidation] = splitEachLabel(allImages,0.85,'randomized');
disp(['Number of training images: ',num2str(numel(imgsTrain.Files))]);

disp(['Number of validation images: ',num2str(numel(imgsValidation.Files))]);

%% load pre-trained network
% Load pre-trained MobileNetV2
net = EffientFrac;
net.Layers
%%
% Display the network structure
%deepNetworkDesigner(net);
analyzeNetwork(net);
%%
% Convert the network to a layer graph
lgraph = layerGraph(net);
numberOfLayers = numel(lgraph.Layers);
figure('Units','normalized','Position',[0.1 0.1 0.8 0.8]);
plot(lgraph)
title(['Layer Graph: ', num2str(numberOfLayers), ' Layers']);
%%
% Define the Squeeze-and-Excitation block with unique layer names

% Add SE Attention block after 'Conv_1_bn' layer
seBlock = seLayer(1280, 16); % 1280 is the number of channels in the 'Conv_1_bn' layer
lgraph = addLayers(lgraph, seBlock);

% Remove conflicting connections
lgraph = disconnectLayers(lgraph, 'efficientnet-b0|model|head|conv2d|Conv2D', 'efficientnet-b0|model|head|tpu_batch_normalization|FusedBatchNorm');

% Add new connections for SE block
lgraph = connectLayers(lgraph, 'efficientnet-b0|model|head|conv2d|Conv2D', 'se_gap_unique');
lgraph = connectLayers(lgraph, 'se_sigmoid_unique', 'se_mult_unique/in2');
lgraph = connectLayers(lgraph, 'se_mult_unique', 'efficientnet-b0|model|head|tpu_batch_normalization|FusedBatchNorm');

% Ensure we don't connect 'Conv_1_bn' to 'se_mult_unique/in1' again if it's already connected
if ~isConnected(lgraph, 'efficientnet-b0|model|head|conv2d|Conv2D', 'se_mult_unique/in1')
    lgraph = connectLayers(lgraph, 'efficientnet-b0|model|head|conv2d|Conv2D', 'se_mult_unique/in1');
end
%%
% Define new classification layers
numClasses = numel(categories(imgsTrain.Labels));
newConnectedLayer = fullyConnectedLayer(numClasses, 'Name', 'newFacME1', ...
    'WeightLearnRateFactor', 5, 'BiasLearnRateFactor', 5);
newClassLayer = classificationLayer('Name', 'new_classoutput');

% Replace the original classification layers
lgraph = replaceLayer(lgraph, 'newFacME', newConnectedLayer);
lgraph = replaceLayer(lgraph, 'new_classoutFrcME', newClassLayer);

% Analyze the modified network
analyzeNetwork(lgraph);
%%
% Freeze the initial layers
layers = lgraph.Layers;
connections = lgraph.Connections;
layers(1:229) = freezeWeights(layers(1:229));
lgraph = createLgraphUsingConnections(layers, connections);
%%
% Training options
options = trainingOptions('adam', ...
    'MiniBatchSize', 10, ...
    'MaxEpochs', 500, ...
    'Shuffle', 'every-epoch', ...
    'InitialLearnRate', 3e-4, ...
    'ValidationData', imgsValidation, ...
    'ValidationFrequency', 10, ...
    'Verbose', 1, ...
    'ExecutionEnvironment', 'cpu', ...
    'Plots', 'training-progress');
rng default
%%
% Train the network
EffientFracAttention = trainNetwork(imgsTrain, lgraph, options);


%% SAVE 
save MobilFracAttention
%%
[YPred,probs] = classify(xceptionMRITL,imgsValidation);
accuracy = mean(YPred==imgsValidation.Labels);
disp(['Accuracy: ',num2str(100*accuracy),'%'])



%%
function data=customReadDatastoreImage(filename)
% code from default function: 
onState = warning('off', 'backtrace'); 
c = onCleanup(@() warning(onState)); 
data = imread(filename); % added lines: 
data = data(:,:,min(1:3, end)); 
%   data = normalize (data, 'range');
data = imresize(data,[224 224]);

end

%%

%layers = freezeWeights(layers)
function layers = freezeWeights(layers)

for ii = 1:size(layers,1)
    props = properties(layers(ii));
    for p = 1:numel(props)
        propName = props{p};
        if ~isempty(regexp(propName, 'LearnRateFactor$', 'once'))
            layers(ii).(propName) = 0;
        end
    end
end

end


%%
% lgraph = createLgraphUsingConnection
function lgraph = createLgraphUsingConnections(layers,connections)

lgraph = layerGraph();
for i = 1:numel(layers)
    lgraph = addLayers(lgraph,layers(i));
end

for c = 1:size(connections,1)
    lgraph = connectLayers(lgraph,connections.Source{c},connections.Destination{c});
end

end

%%
% Define the Squeeze-and-Excitation block with unique layer names
function seBlock = seLayer(numChannels, ratio)
    seBlock = [
        globalAveragePooling2dLayer('Name', 'se_gap_unique')
        fullyConnectedLayer(numChannels / ratio, 'Name', 'se_fc1_unique', 'WeightsInitializer', 'glorot')
        reluLayer('Name', 'se_relu_unique')
        fullyConnectedLayer(numChannels, 'Name', 'se_fc2_unique', 'WeightsInitializer', 'glorot')
        sigmoidLayer('Name', 'se_sigmoid_unique')
        multiplicationLayer(2, 'Name', 'se_mult_unique')];
end

%% Helper function to check if layers are already connected
function isConn = isConnected(lgraph, sourceName, destName)
    connections = lgraph.Connections;
    isConn = any(strcmp(connections.Source, sourceName) & strcmp(connections.Destination, destName));
end