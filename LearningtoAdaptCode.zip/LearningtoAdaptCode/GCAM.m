


net = MobilTLbigFinger; 
%net = xceptionbigTLshoulderV3;
X = imread("image1 (34)_resized.png");
inputSize = net.Layers(1).InputSize(1:2);
X = imresize(X,inputSize);
% imshow(X)
label = classify(net,X);
scoreMap = gradCAM(net,X,label);
figure
imshow(X)
hold on
imagesc(scoreMap,'AlphaData',0.5)
colormap jet

label