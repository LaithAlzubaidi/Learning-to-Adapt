% Load test dataset
load('TEST_dataset.mat'); % Load your test dataset here

X_test = TEST_dataset.X; 
y_test = TEST_dataset.y; 

% Predict using each classifier
pred1 = predict(SVMModel, X_test);
pred2 = round(predict(LogisticModel, X_test)); % Logistic regression output needs rounding
pred3 = predict(KNNModel, X_test);
pred4 = predict(NaiveBayesModel, X_test);
pred5 = predict(TreeModel, X_test);

% Combine predictions into a matrix
predictions = [pred1, pred2, pred3, pred4, pred5];

% Apply majority voting
numSamples = size(predictions, 1); % Number of samples
finalPredictions = zeros(numSamples, 1);

for i = 1:numSamples
    % Get the predictions for the i-th sample from all classifiers
    samplePreds = predictions(i, :);
    
    % Determine the majority vote
    uniqueVals = unique(samplePreds);
    counts = histcounts(samplePreds, [uniqueVals - 0.5, max(uniqueVals) + 0.5]);
    [~, maxIdx] = max(counts);
    finalPredictions(i) = uniqueVals(maxIdx);
end

% Display final predictions
disp('Final Predictions:');
disp(finalPredictions);

% Evaluate the final predictions
accuracy = sum(finalPredictions == y_test) / length(y_test);
disp(['Accuracy: ', num2str(accuracy * 100), '%']);
