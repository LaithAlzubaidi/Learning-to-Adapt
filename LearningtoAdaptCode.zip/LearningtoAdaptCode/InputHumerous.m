A= 'C:\Users\ALZUBAID\OneDrive - Queensland University of Technology\Desktop\New-Orthopedics\Humeous-done\Humerus';
parentDir = A;
 dataDir = 'Train';

%%  Divide into Training and Validation Data

TrainHumerus = imageDatastore(fullfile(parentDir,dataDir),...
    'IncludeSubfolders',true,...
    'LabelSource','foldernames');
 TrainHumerus.ReadFcn = @customReadDatastoreImage;
disp(['Number of Train29: ',num2str(numel(TrainHumerus.Files))]);

%%
B= 'C:\Users\ALZUBAID\OneDrive - Queensland University of Technology\Desktop\New-Orthopedics\Humeous-done\Humerus';
parentDir = B;
 dataDir = 'Test';

%%  Divide into Training and Validation Data

TestHumerus= imageDatastore(fullfile(parentDir,dataDir),...
    'IncludeSubfolders',true,...
    'LabelSource','foldernames');
  TestHumerus.ReadFcn = @customReadDatastoreImage;
disp(['Number of Test29: ',num2str(numel(TestHumerus.Files))]);
%%
net1 = xceptionTLbigHumerousV3;
net2 = inceptionresnetigHumerousV3;



% analyzeNetwork(net1)
%% 
% last FC to extract the features
layer1='newHumerous';
layer2='newHumerous';


%%

FeatureTrainXCEPTION = activations(net1,TrainHumerus,layer1,'outputAs','rows');
 FeatureTestXCEPTION = activations(net1,TestHumerus,layer1,'outputAs','rows');

whos FeatureTrainXCEPTION



FeatureTrainInceptionRes = activations(net2,TrainHumerus,layer2,'outputAs','rows');
 FeatureTest2InceptionRes = activations(net2,TestHumerus,layer2,'outputAs','rows');

whos FeatureTrainInceptionRes




 %%
 FeatureTrainallHumerus=[FeatureTrainXCEPTION FeatureTrainInceptionRes];
 FeatureTestallHumerus=[FeatureTestXCEPTION FeatureTest2InceptionRes];



%%

TrainLabelHumerus=TrainHumerus.Labels;
TestLabelHumerus=TestHumerus.Labels;


%%
function data=customReadDatastoreImage(filename)
% code from default function: 
onState = warning('off', 'backtrace'); 
c = onCleanup(@() warning(onState)); 
data = imread(filename); % added lines: 
data = data(:,:,min(1:3, end)); 
data = imresize(data,[299 299]);
end
