A= 'C:\Users\ALZUBAID\OneDrive - Queensland University of Technology\Desktop\New-Orthopedics\Elbow-done\Elbow';
parentDir = A;
 dataDir = 'Train';

%%  Divide into Training and Validation Data

Trainelbow = imageDatastore(fullfile(parentDir,dataDir),...
    'IncludeSubfolders',true,...
    'LabelSource','foldernames');
 Trainelbow.ReadFcn = @customReadDatastoreImage;
disp(['Number of Train29: ',num2str(numel(Trainelbow.Files))]);

%%
B= 'C:\Users\ALZUBAID\OneDrive - Queensland University of Technology\Desktop\New-Orthopedics\Elbow-done\Elbow';
parentDir = B;
 dataDir = 'Test';

%%  Divide into Training and Validation Data

Testelbow= imageDatastore(fullfile(parentDir,dataDir),...
    'IncludeSubfolders',true,...
    'LabelSource','foldernames');
  Testelbow.ReadFcn = @customReadDatastoreImage;
disp(['Number of Test29: ',num2str(numel(Testelbow.Files))]);
%%
net1 = xceptionTLbigElbowV2;
net2 = inceptionresnetv2TLelbowV333;



% analyzeNetwork(net1)
%% 
% last FC to extract the features
layer1='newelbow1';
layer2='newElbow';


%%

FeatureTrainXCEPTION = activations(net1,Trainelbow,layer1,'outputAs','rows');
 FeatureTestXCEPTION = activations(net1,Testelbow,layer1,'outputAs','rows');

whos FeatureTrainXCEPTION



FeatureTrainInceptionRes = activations(net2,Trainelbow,layer2,'outputAs','rows');
 FeatureTest2InceptionRes = activations(net2,Testelbow,layer2,'outputAs','rows');

whos FeatureTrainInceptionRes




 %%
 FeatureTrainallElbow=[FeatureTrainXCEPTION FeatureTrainInceptionRes];
 FeatureTestallElbow=[FeatureTestXCEPTION FeatureTest2InceptionRes];



%%
% TrainLabel= Train29.Labels; 

TrainLabelelbow=Trainelbow.Labels;
TestLabelelbow=Testelbow.Labels;


%%
function data=customReadDatastoreImage(filename)
% code from default function: 
onState = warning('off', 'backtrace'); 
c = onCleanup(@() warning(onState)); 
data = imread(filename); % added lines: 
data = data(:,:,min(1:3, end)); 
data = imresize(data,[299 299]);
end
